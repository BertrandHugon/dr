<?php
// -----------------------------------------
// crypte une chaine
// -----------------------------------------

		
function crypto($maCleDeCryptage="", $maChaineACrypter)
{
 	if($maCleDeCryptage=="")
	{ 
		$maCleDeCryptage=$GLOBALS['PHPSESSID']; 
	}
 
	$maCleDeCryptage = md5($maCleDeCryptage); 
	$letter = -1; 
	$newstr = ''; 
	$strlen = strlen($maChaineACrypter); 
	for($i = 0; $i < $strlen; $i++)
	{
		$letter++;
		if ($letter > 31)
		{
			$letter = 0;
		} 
		$neword = ord($maChaineACrypter{$i}) + ord($maCleDeCryptage{$letter});
 
		if ($neword > 255)
		{
			$neword -= 256;
		} 
		$newstr .= chr($neword); 
	} 
	return base64_encode($newstr);
}
 
	$circArray = array("CircOM", "CircSO", "CircSE",  "CircIDF", 
				  "CircE",  "CircNO", "CircMCC", "CircO");
	
	$id 	= $_POST['id'];
	$email 	= $_POST['email'];
	$pseudo = $_POST['pseudo'];
	$circ 	= $circArray[$id - 1];
	$error = "6";
	
	header('Location: inscription.php?id=' . $id . '&error=7'); 

	if (!empty($email))
	{
		$errorMail = 0;
		$strlen = strlen($email);
	 
		for ($i = 0; $i < $strlen; $i++)
		{
			if (empty($okarobase))
			{
				if ($email{$i} == '@')
				{
					$okarobase = "1";
				}
			}
			else 
			{
				if ($email{$i} == '@')
				{
					$errorMail = 1;
				}
				
				if (empty($okpoint) && $email{$i} == '.')
				{
					$okpoint = "1";
				}
				else if ($email{$i} == '.')
				{
					$errorMail = 1;
				}
			}
		}
		if ($errorMail == 0 && !empty($okpoint))
		{
			$emailValid = "value";
		}
	}
	
	if (!empty($pseudo))
	{
		$strlen = strlen($pseudo);
	 
		for ($i = 0; $i < $strlen; $i++)
		{
			if ($pseudo{$i} == '|')
			{
				$error = "5";
				break;
			}
		}
	}
	
	if ($error == "5")
	{
		header('Location: inscription.php?id=' . $id . '&error=' . $error); 
	}
	else if (empty($emailValid))
	{
		$error = "3";
		header('Location: inscription.php?id=' . $id . '&error=' . $error); 
	}
	else if (!empty($circ) && !empty($emailValid) && !empty($pseudo))
	{
		$db = mysql_connect('91.216.107.219', 'democ338831', 'IyXXZHDc80Z'); 
		
		mysql_select_db('democ338831',$db);
		
		$request = "SELECT 'found'
from (SELECT count(*) as c1 from " . $circArray[0] . "  where EMAIL ='" . $email . "' ) as t1,
     (SELECT count(*) as c2 from " . $circArray[1] . "  where EMAIL ='" . $email . "' ) as t2,
     (SELECT count(*) as c3 from " . $circArray[2] . "  where EMAIL ='" . $email . "' ) as t3,
     (SELECT count(*) as c4 from " . $circArray[3] . "  where EMAIL ='" . $email . "' ) as t4,
     (SELECT count(*) as c5 from " . $circArray[4] . "  where EMAIL ='" . $email . "' ) as t5,
     (SELECT count(*) as c6 from " . $circArray[5] . "  where EMAIL ='" . $email . "' ) as t6,
     (SELECT count(*) as c7 from " . $circArray[6] . "  where EMAIL ='" . $email . "' ) as t7,
     (SELECT count(*) as c8 from " . $circArray[7] . "  where EMAIL ='" . $email . "' ) as t8
	 WHERE c1 > 0 OR c2 > 0 OR c3 > 0 OR c4 > 0 OR c5 > 0 OR c6 > 0 OR c7 > 0 OR c8 > 0";
							
		$req =  mysql_query($request) 
				or die('Erreur SQL !<br>'.$request.'<br>'.mysql_error());
				
		$line = mysql_fetch_assoc($req);
		
		if (empty($line))
		{
			$toCrypt 	= $pseudo . "|" . $email . "|" . $circ; 
			$key 		= "Huj*78Jusi";
			$crypted	= crypto($key, $toCrypt);
			
			$headers  ='From: "DemocratieReelle"<ne_pas_repondre@democratiereelle.fr>'."\n"; 
			$headers .='Reply-To: ne_pas_repondre@democratiereelle.fr'."\n"; 
			$headers .='Content-Type: text/html; charset="iso-8859-1"'."\n"; 
		 	$headers .='Content-Transfer-Encoding: 8bit'; 
		
			mail($email, 
				 'DemocratieReelle Inscription', 
				 'Bonjour ' . $pseudo .
				 ',<br/><br/>Pour confirmer votre inscription, cliquez sur <a style="font-size:30px;"  href="http://www.democratiereelle.eu/inscription.php?c=' . $crypted . '" >ce lien.</a><br/><br/>Rendez-vous Juin 2013 pour le tirage au sort.<br/><br/>Cordialement,<br/><br/><a href="http://www.democratiereelle.fr/">www.democratiereelle.fr</a>', 
				 $headers); 
		}
		else
		{
			$error = "2"; 
		}
		
		mysql_close($db);
		header('Location: inscription.php?id=' . $id . '&error=' . $error); 
	}
	else
	{
		$error = "1"; 
		header('Location: inscription.php?id=' . $id . '&error=' . $error); 
	}
	
?>